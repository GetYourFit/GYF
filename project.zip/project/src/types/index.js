// User preferences for styling recommendations
export const UserPreferences = {};

// Individual clothing item
export const OutfitItem = {};

// Complete outfit with multiple items
export const Outfit = {};

// Shopping cart item
export const CartItem = {};

// Search and filter options
export const SearchFilters = {};

// Camera analysis results
export const CameraAnalysis = {};